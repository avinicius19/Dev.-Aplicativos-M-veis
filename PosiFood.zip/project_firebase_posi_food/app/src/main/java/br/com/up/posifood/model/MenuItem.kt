package br.com.up.posifood.model

data class MenuItem(
    var description:String,
    var name:String,
    var price:Double
)
